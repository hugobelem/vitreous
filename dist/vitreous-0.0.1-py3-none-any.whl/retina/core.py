def hello():
    print('Hello')